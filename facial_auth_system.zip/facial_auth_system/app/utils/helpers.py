"""
app/utils/helpers.py

Shared utility functions used across modules.
Module 1 should already contain some of these; this file
contains the complete, verified set needed through Module 3.
"""

import io
import numpy as np


# ──────────────────────────────────────────────
# Embedding serialization (Module 1 / Module 3)
# ──────────────────────────────────────────────

def serialize_embedding(vector: np.ndarray) -> bytes:
    """
    Serialize a numpy float32 array to raw bytes for SQLite BLOB storage.

    Args:
        vector (np.ndarray): 1-D float32 embedding.

    Returns:
        bytes: Binary representation of the array.
    """
    buf = io.BytesIO()
    np.save(buf, vector.astype(np.float32))
    return buf.getvalue()


def deserialize_embedding(blob: bytes) -> np.ndarray:
    """
    Deserialize a SQLite BLOB back to a numpy float32 array.

    Args:
        blob (bytes): Binary data previously created by serialize_embedding().

    Returns:
        np.ndarray: 1-D float32 embedding.
    """
    buf = io.BytesIO(blob)
    return np.load(buf).astype(np.float32)


# ──────────────────────────────────────────────
# Vector math (Module 3)
# ──────────────────────────────────────────────

def l2_normalize(vector: np.ndarray) -> np.ndarray:
    """
    Divide a vector by its L2 (Euclidean) norm.

    If the norm is zero (zero vector), the vector is returned unchanged
    to avoid division by zero.

    Args:
        vector (np.ndarray): 1-D numpy array.

    Returns:
        np.ndarray: Unit-length vector, same dtype as input.
    """
    norm = np.linalg.norm(vector)
    if norm == 0.0:
        return vector
    return (vector / norm).astype(vector.dtype)


def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """
    Compute cosine similarity between two L2-normalized vectors.

    Because both inputs are already unit-length, this reduces to
    a simple dot product. The result is clamped to [0.0, 1.0] to
    guard against floating-point rounding that would otherwise
    produce values like 1.0000002.

    Args:
        vec1 (np.ndarray): L2-normalized 1-D float array.
        vec2 (np.ndarray): L2-normalized 1-D float array, same shape.

    Returns:
        float: Similarity in [0.0, 1.0]. 1.0 = identical, 0.0 = orthogonal.
    """
    score = float(np.dot(vec1, vec2))
    return max(0.0, min(1.0, score))


def is_match(similarity: float, threshold: float) -> bool:
    """
    Decide whether a similarity score clears the acceptance threshold.

    Args:
        similarity (float): Output of cosine_similarity().
        threshold (float): Minimum score to accept as a genuine match.

    Returns:
        bool: True if similarity >= threshold.
    """
    return similarity >= threshold
