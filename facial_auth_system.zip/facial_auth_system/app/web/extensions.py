"""
app/web/extensions.py

Flask app factory and shared singleton objects.
All core ML objects are initialized once here and reused across
every request -- no reloading per request.
"""

import sys
from pathlib import Path
from flask import Flask
from flask_session import Session

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from config import DB_PATH
from app.database.db_manager import DatabaseManager
from app.core.face_detector import FaceDetector
from app.core.face_recognizer import FaceRecognizer
from app.core.liveness import LivenessChecker

# ---------------------------------------------------------------------------
# Singletons -- initialized once at startup, shared across all requests
# ---------------------------------------------------------------------------
db_manager       = None
face_detector    = None
face_recognizer  = None
liveness_checker = None


def create_app():
    """
    Flask application factory.
    Initializes all ML objects once, registers blueprints, returns app.
    """
    global db_manager, face_detector, face_recognizer, liveness_checker

    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )

    app.config["SECRET_KEY"] = "faceauth-fyp-secret-change-in-production"
    app.config["SESSION_TYPE"] = "filesystem"
    app.config["SESSION_FILE_DIR"] = str(
        Path(__file__).resolve().parents[2] / "data" / "sessions"
    )
    app.config["SESSION_PERMANENT"] = False
    Path(app.config["SESSION_FILE_DIR"]).mkdir(parents=True, exist_ok=True)

    Session(app)

    print("[FaceAuth] Initializing core objects...")
    db_manager       = DatabaseManager(DB_PATH)
    face_detector    = FaceDetector()
    face_recognizer  = FaceRecognizer(db_manager)
    liveness_checker = LivenessChecker(face_detector)
    print("[FaceAuth] All systems ready.")

    from app.web.routes.auth  import auth_bp
    from app.web.routes.admin import admin_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    return app
