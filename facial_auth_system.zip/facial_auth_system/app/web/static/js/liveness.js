/**
 * static/js/liveness.js
 *
 * Polls /liveness/status every 500ms to update the stats panel.
 * The actual video is served as MJPEG by /liveness/stream directly
 * into the <img> tag -- no JS needed for the video itself.
 * Once all frames are analyzed, calls /liveness/complete and redirects.
 */

(function () {
  "use strict";

  const FRAMES_NEEDED = parseInt(
    document.getElementById("frames-needed").value, 10
  );

  const statusEl   = document.getElementById("camera-status");
  const progressEl = document.getElementById("liveness-progress");
  const countEl    = document.getElementById("frames-count");
  const earEl      = document.getElementById("metric-ear");
  const blinksEl   = document.getElementById("metric-blinks");
  const scoreEl    = document.getElementById("metric-score");
  const shieldEl   = document.getElementById("shield-status");

  let completed = false;

  async function pollStatus() {
    if (completed) return;

    try {
      const resp = await fetch("/liveness/status");
      if (!resp.ok) return;
      const data = await resp.json();

      if (data.error) {
        statusEl.textContent = "Error: " + data.error;
        statusEl.style.color = "#ef4444";
        return;
      }

      // Update progress bar
      const pct = Math.min((data.frame_count / FRAMES_NEEDED) * 100, 100);
      progressEl.style.width = pct + "%";
      countEl.textContent    = data.frame_count + " / " + data.frames_needed;

      if (data.no_face) {
        statusEl.textContent = "No face detected -- move closer";
        statusEl.style.color = "#f59e0b";
      } else if (data.frame_count > 0) {
        statusEl.textContent = "Analyzing... frame " + data.frame_count + " / " + data.frames_needed;
        statusEl.style.color = "#ffffff";

        // Update metrics
        earEl.textContent    = data.last_ear;
        blinksEl.textContent = data.last_blinks;
        scoreEl.textContent  = data.last_score;

        if (data.last_is_real) {
          shieldEl.className   = "alert alert-success mt-1";
          shieldEl.textContent = "EasyShield: REAL (" + data.last_score + ")";
        } else {
          shieldEl.className   = "alert alert-error mt-1";
          shieldEl.textContent = "EasyShield: FAKE (" + data.last_score + ")";
        }
      }

      // All frames done -- call complete endpoint and redirect
      if (data.complete && !completed) {
        completed = true;
        statusEl.textContent = "Analysis complete. Processing result...";
        statusEl.style.color = "#4ade80";

        try {
          const cResp = await fetch("/liveness/complete", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({}),
          });
          const cData = await cResp.json();
          if (cData.redirect) {
            window.location.href = cData.redirect;
          } else if (cData.error) {
            statusEl.textContent = "Error: " + cData.error;
            statusEl.style.color = "#ef4444";
          }
        } catch (err) {
          statusEl.textContent = "Network error: " + err.message;
        }
      }

    } catch (err) {
      // Network hiccup -- just wait for next poll
    }
  }

  // Poll every 500ms
  setInterval(pollStatus, 500);

  // Initial status call immediately
  pollStatus();
})();
