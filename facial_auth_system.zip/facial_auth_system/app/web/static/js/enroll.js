/**
 * static/js/enroll.js
 *
 * Enrollment webcam capture.
 * User clicks "Capture Sample" to add one sample at a time,
 * OR clicks "Auto Capture" to collect all samples automatically
 * every 800ms without further interaction.
 */

(function () {
  "use strict";

  const SAMPLES_NEEDED = parseInt(
    document.getElementById("samples-needed").value, 10
  );
  const MIN_SAMPLES = parseInt(
    document.getElementById("min-samples").value, 10
  );

  const video       = document.getElementById("enroll-video");
  const canvas      = document.getElementById("enroll-canvas");
  const ctx         = canvas.getContext("2d");
  const statusEl    = document.getElementById("enroll-status");
  const progressEl  = document.getElementById("enroll-progress");
  const countEl     = document.getElementById("sample-count");
  const thumbGrid   = document.getElementById("thumb-grid");
  const captureBtn  = document.getElementById("capture-btn");
  const autoBtn     = document.getElementById("auto-btn");
  const enrollBtn   = document.getElementById("enroll-btn");
  const enrollMsg   = document.getElementById("enroll-msg");

  let stream       = null;
  let autoTimer    = null;
  let sampleCount  = 0;
  let sending      = false;

  // ── Start webcam ─────────────────────────────────────────────────
  async function startCamera() {
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: false,
      });
      video.srcObject = stream;
      await video.play();
      setStatus("Camera ready. Look at the camera.", "ok");
    } catch (err) {
      setStatus("Camera error: " + err.message, "error");
    }
  }

  // ── Capture and send one frame ───────────────────────────────────
  async function captureFrame() {
    if (sending || sampleCount >= SAMPLES_NEEDED) return;

    sending = true;
    canvas.width  = video.videoWidth  || 640;
    canvas.height = video.videoHeight || 480;
    ctx.drawImage(video, 0, 0);
    const b64 = canvas.toDataURL("image/jpeg", 0.85);

    try {
      const resp = await fetch("/admin/enroll/frame", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ frame: b64 }),
      });
      const data = await resp.json();

      if (data.error) {
        setStatus("Error: " + data.error, "error");
        sending = false;
        return;
      }

      if (!data.accepted) {
        setStatus(data.reason || "Sample rejected.", "warn");
        sending = false;
        return;
      }

      // Accepted
      sampleCount = data.sample_count;
      updateProgress(sampleCount);
      setStatus(
        "Sample " + sampleCount + " captured (quality: " + data.quality + ")",
        "ok"
      );

      // Add thumbnail
      if (data.face_preview) {
        const img = document.createElement("img");
        img.src = "data:image/jpeg;base64," + data.face_preview;
        img.title = "Sample " + sampleCount;
        thumbGrid.appendChild(img);
      }

      // Enable enroll button once minimum reached
      if (sampleCount >= MIN_SAMPLES) {
        enrollBtn.disabled = false;
        enrollMsg.style.display = "none";
      }

      // Auto-stop when target reached
      if (sampleCount >= SAMPLES_NEEDED) {
        stopAuto();
        setStatus("All " + SAMPLES_NEEDED + " samples captured. Click Enroll.", "ok");
      }
    } catch (err) {
      setStatus("Network error: " + err.message, "error");
    }

    sending = false;
  }

  // ── Auto capture ─────────────────────────────────────────────────
  function startAuto() {
    if (autoTimer) return;
    autoBtn.textContent = "Stop Auto";
    autoBtn.classList.replace("btn-secondary", "btn-warning");
    autoTimer = setInterval(captureFrame, 800);
    setStatus("Auto-capture running...", "ok");
  }

  function stopAuto() {
    clearInterval(autoTimer);
    autoTimer = null;
    autoBtn.textContent = "Auto Capture";
    autoBtn.classList.replace("btn-warning", "btn-secondary");
  }

  // ── Enroll ───────────────────────────────────────────────────────
  async function doEnroll() {
    enrollBtn.disabled   = true;
    enrollBtn.textContent = "Enrolling...";

    try {
      const resp = await fetch("/admin/enroll/complete", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({}),
      });
      const data = await resp.json();

      if (data.success) {
        stopCamera();
        stopAuto();
        setStatus(
          "Enrolled! " + data.valid_count + " samples, dim=" + data.embedding_dim,
          "ok"
        );
        // Redirect back to dashboard after short delay
        setTimeout(() => { window.location.href = "/admin/dashboard"; }, 1500);
      } else {
        setStatus("Enrollment failed: " + (data.error || "Unknown error"), "error");
        enrollBtn.disabled   = false;
        enrollBtn.textContent = "Enroll User";
      }
    } catch (err) {
      setStatus("Network error: " + err.message, "error");
      enrollBtn.disabled   = false;
      enrollBtn.textContent = "Enroll User";
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────
  function updateProgress(count) {
    const pct = Math.min((count / SAMPLES_NEEDED) * 100, 100);
    progressEl.style.width = pct + "%";
    countEl.textContent    = count + " / " + SAMPLES_NEEDED;
  }

  function setStatus(msg, type) {
    statusEl.textContent = msg;
    statusEl.className   = "alert alert-" + (
      type === "error" ? "error" :
      type === "warn"  ? "warning" :
      "success"
    ) + " mt-1";
    statusEl.style.display = "flex";
  }

  function stopCamera() {
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      stream = null;
    }
  }

  // ── Wire up buttons ───────────────────────────────────────────────
  captureBtn.addEventListener("click", captureFrame);
  autoBtn.addEventListener("click", function () {
    if (autoTimer) stopAuto(); else startAuto();
  });
  enrollBtn.addEventListener("click", doEnroll);

  const clearBtn = document.getElementById("clear-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", function () {
      window.location.reload();
    });
  }

  // ── Boot ──────────────────────────────────────────────────────────
  startCamera();
})();
