"""
app/web/video_stream.py

MJPEG video streaming with real-time liveness overlays.

This replicates the test_module4.py --live approach exactly:
  - cv2.VideoCapture(0) reads frames in a background thread
  - Each frame gets face detection + liveness check
  - Overlays are drawn directly on the frame (EAR, blinks,
    EasyShield score, frame counter) using cv2.putText
  - Frames are JPEG-encoded and streamed to the browser as
    multipart/x-mixed-replace (MJPEG)
  - The browser <img> tag displays it as smooth live video

One LivenessSession object exists per browser session.
The Flask route /liveness/stream serves the MJPEG feed.
The Flask route /liveness/status returns JSON with current stats.
The Flask route /liveness/complete evaluates the verdict.
"""

import cv2
import time
import threading
import numpy as np


class LivenessSession:
    """
    Manages one user's liveness check session.
    Runs cv2.VideoCapture in a background thread, processes every
    frame through FaceDetector + LivenessChecker, draws overlays,
    and exposes JPEG frames for MJPEG streaming.
    """

    def __init__(self, face_detector, liveness_checker, frames_needed):
        self.face_detector    = face_detector
        self.liveness_checker = liveness_checker
        self.frames_needed    = frames_needed

        # State (read by Flask routes)
        self.frame_count   = 0
        self.last_ear      = 0.0
        self.last_blinks   = 0
        self.last_score    = 0.0
        self.last_is_real  = False
        self.best_face     = None   # 160x160 RGB numpy array
        self.best_quality  = 0.0
        self.complete      = False
        self.no_face       = False
        self.error         = None

        self._lock         = threading.Lock()
        self._latest_jpeg  = None   # bytes of most recent annotated JPEG frame
        self._stop         = threading.Event()
        self._cap          = None

        # Start background thread
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    # ------------------------------------------------------------------
    # Background capture + processing thread
    # ------------------------------------------------------------------

    def _run(self):
        """
        Mirrors the while loop in test_module4.py run_live_test().
        Reads frames, runs detection + liveness, draws overlays,
        encodes to JPEG for streaming.
        """
        cap = cv2.VideoCapture(1)
        if not cap.isOpened():
            with self._lock:
                self.error = "Cannot open camera (index 0)."
            return

        self._cap = cap
        self.liveness_checker.reset_session()

        while not self._stop.is_set():
            ret, frame = cap.read()
            if not ret or frame is None:
                time.sleep(0.05)
                continue

            # Mirror the frame horizontally (selfie view)
            frame = cv2.flip(frame, 1)
            display = frame.copy()
            h, w = display.shape[:2]

            # Run face detection
            try:
                detection = self.face_detector.detect_face(frame)
            except Exception:
                detection = None

            # Run liveness check and draw overlays (same as test_module4.py)
            if detection is not None:
                try:
                    cf = self.liveness_checker.check_frame(frame, detection)
                except Exception:
                    cf = {"face_present": False}

                if cf.get("face_present"):
                    # Draw bounding box
                    x, y, bw, bh = detection["bbox"]
                    cv2.rectangle(display, (x, y), (x + bw, y + bh), (0, 255, 0), 2)

                    # EAR overlay
                    ear_text = (
                        "EAR  L:{:.2f}  R:{:.2f}  Avg:{:.2f}".format(
                            cf["left_ear"], cf["right_ear"], cf["avg_ear"]
                        )
                    )
                    cv2.putText(
                        display, ear_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200, 200, 50), 1
                    )

                    # Blink count
                    blink_col = (0, 255, 0) if cf["blink_detected"] else (0, 200, 255)
                    cv2.putText(
                        display,
                        "Blinks: {}".format(cf["total_blinks"]),
                        (10, 58),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, blink_col, 2
                    )

                    # EasyShield score
                    if cf["cnn_is_real"]:
                        spoof_col  = (0, 220, 0)
                        spoof_text = "EasyShield: REAL ({:.2f})".format(
                            cf["cnn_real_score"]
                        )
                    else:
                        spoof_col  = (0, 0, 220)
                        spoof_text = "EasyShield: FAKE ({:.2f})".format(
                            cf["cnn_real_score"]
                        )
                    cv2.putText(
                        display, spoof_text, (10, 86),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, spoof_col, 2
                    )

                    # Track best face for recognition
                    try:
                        quality = self.face_detector.get_face_quality_score(
                            detection["face_image"]
                        )
                        with self._lock:
                            if quality > self.best_quality:
                                self.best_face    = detection["face_image"]
                                self.best_quality = quality
                    except Exception:
                        pass

                    # Update shared state
                    with self._lock:
                        self.frame_count  += 1
                        self.last_ear      = cf["avg_ear"]
                        self.last_blinks   = cf["total_blinks"]
                        self.last_score    = cf["cnn_real_score"]
                        self.last_is_real  = cf["cnn_is_real"]
                        self.no_face       = False

                        if self.frame_count >= self.frames_needed:
                            self.complete = True
                else:
                    with self._lock:
                        self.no_face = True
            else:
                with self._lock:
                    self.no_face = True
                # Draw "No face" message
                cv2.putText(
                    display,
                    "No face detected -- move closer",
                    (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2
                )

            # Frame counter (top right)
            with self._lock:
                fc = self.frame_count
            cv2.putText(
                display,
                "Frames: {}/{}".format(fc, self.frames_needed),
                (w - 220, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 1
            )

            # "COMPLETE" banner when done
            with self._lock:
                done = self.complete
            if done:
                cv2.putText(
                    display,
                    "Analysis complete!",
                    (w // 2 - 140, h - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2
                )

            # Encode frame to JPEG
            _, buf = cv2.imencode(
                ".jpg", display,
                [cv2.IMWRITE_JPEG_QUALITY, 80]
            )
            with self._lock:
                self._latest_jpeg = buf.tobytes()

            # Stop once complete -- let last frame render first
            if done:
                time.sleep(0.5)
                break

        cap.release()
        self._cap = None

    # ------------------------------------------------------------------
    # MJPEG frame generator (called by Flask route)
    # ------------------------------------------------------------------

    def generate_frames(self):
        """
        Generator that yields MJPEG multipart frames.
        Used by the Flask streaming route:

            Response(session.generate_frames(),
                     mimetype="multipart/x-mixed-replace; boundary=frame")
        """
        while not self._stop.is_set():
            with self._lock:
                jpeg = self._latest_jpeg
                done = self.complete

            if jpeg:
                yield (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + jpeg +
                    b"\r\n"
                )
            else:
                time.sleep(0.05)
                continue

            if done:
                break

            time.sleep(0.033)  # ~30 fps cap

    # ------------------------------------------------------------------
    # Stats snapshot (called by /liveness/status)
    # ------------------------------------------------------------------

    def get_status(self):
        with self._lock:
            return {
                "frame_count":  self.frame_count,
                "frames_needed": self.frames_needed,
                "last_ear":     round(self.last_ear,   3),
                "last_blinks":  self.last_blinks,
                "last_score":   round(self.last_score, 2),
                "last_is_real": self.last_is_real,
                "no_face":      self.no_face,
                "complete":     self.complete,
                "error":        self.error,
            }

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def stop(self):
        self._stop.set()
        if self._cap:
            try:
                self._cap.release()
            except Exception:
                pass
