"""
app/web/routes/admin.py

Admin routes (all prefixed with /admin):
  GET/POST /admin/login
  GET      /admin/logout
  GET      /admin/dashboard
  POST     /admin/user/add
  POST     /admin/user/delete
  GET      /admin/enroll/<user_id>
  POST     /admin/enroll/frame     -- receive enrollment frame from JS
  POST     /admin/enroll/complete  -- finalize enrollment
  GET      /admin/logs
  GET      /admin/logs/export      -- CSV download
"""

import io
import re
import cv2
import csv
import base64
import numpy as np
from datetime import datetime
from functools import wraps
from flask import (
    Blueprint, render_template, request,
    session, redirect, url_for, jsonify,
    Response
)
import app.web.extensions as ext
from config import ENROLLMENT_SAMPLES, MIN_ENROLLMENT_SAMPLES, MIN_FACE_QUALITY

admin_bp = Blueprint("admin", __name__)


# ---------------------------------------------------------------------------
# Auth guard
# ---------------------------------------------------------------------------

def admin_required(f):
    """Decorator: redirect to login if admin not authenticated."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin.login"))
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _validate_user_id(uid):
    return bool(re.match(r'^[A-Za-z0-9\-]{3,}$', uid))


def _decode_frame(b64_data):
    try:
        if "," in b64_data:
            b64_data = b64_data.split(",")[1]
        img_bytes = base64.b64decode(b64_data)
        arr = np.frombuffer(img_bytes, dtype=np.uint8)
        return cv2.imdecode(arr, cv2.IMREAD_COLOR)
    except Exception as e:
        print(f"[admin] _decode_frame error: {e}")
        return None


# ---------------------------------------------------------------------------
# Login / Logout
# ---------------------------------------------------------------------------

@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        uid = request.form.get("user_id", "").strip()
        if not uid:
            error = "Please enter your admin ID."
        else:
            user = ext.db_manager.get_user(uid)
            if user is None or user.get("role") != "admin":
                error = "Invalid admin ID or insufficient permissions."
            elif not user.get("is_active", 1):
                error = "This account has been deactivated."
            else:
                session["admin_logged_in"] = True
                session["admin_user_id"]   = uid
                session["admin_name"]      = user.get("name", uid)
                ext.db_manager.log_event(
                    "ADMIN_LOGIN",
                    user_id=uid,
                    details={"message": "Admin panel accessed"},
                )
                return redirect(url_for("admin.dashboard"))
    return render_template("admin/login.html", error=error)


@admin_bp.route("/logout")
def logout():
    session.pop("admin_logged_in", None)
    session.pop("admin_user_id", None)
    session.pop("admin_name", None)
    session.pop("enroll_samples", None)
    return redirect(url_for("admin.login"))


# ---------------------------------------------------------------------------
# Dashboard -- user table
# ---------------------------------------------------------------------------

@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    users = ext.db_manager.get_all_users()
    user_rows = []
    for u in users:
        enrolled = ext.db_manager.get_embedding(u["user_id"]) is not None
        user_rows.append({
            "name":       u.get("name", ""),
            "user_id":    u.get("user_id", ""),
            "role":       u.get("role", "user"),
            "enrolled":   enrolled,
            "created_at": u.get("created_at", ""),
        })
    return render_template(
        "admin/dashboard.html",
        users=user_rows,
        admin_name=session.get("admin_name", "Admin"),
        current_admin=session.get("admin_user_id"),
    )


# ---------------------------------------------------------------------------
# Add user
# ---------------------------------------------------------------------------

@admin_bp.route("/user/add", methods=["POST"])
@admin_required
def add_user():
    name    = request.form.get("name", "").strip()
    uid     = request.form.get("user_id", "").strip()
    role    = request.form.get("role", "user")
    error   = None

    if not name:
        error = "Full name is required."
    elif not uid:
        error = "User ID is required."
    elif not _validate_user_id(uid):
        error = "Invalid User ID format. Use letters, digits, and hyphens only (min 3 chars)."
    else:
        ok = ext.db_manager.add_user(name=name, user_id=uid, role=role)
        if ok:
            ext.db_manager.log_event(
                "ENROLLED",
                user_id=uid,
                details={"action": "user_created", "role": role},
            )
        else:
            error = f"User ID '{uid}' already exists."

    if error:
        # Re-render dashboard with error
        users = ext.db_manager.get_all_users()
        user_rows = []
        for u in users:
            enrolled = ext.db_manager.get_embedding(u["user_id"]) is not None
            user_rows.append({
                "name":       u.get("name", ""),
                "user_id":    u.get("user_id", ""),
                "role":       u.get("role", "user"),
                "enrolled":   enrolled,
                "created_at": u.get("created_at", ""),
            })
        return render_template(
            "admin/dashboard.html",
            users=user_rows,
            admin_name=session.get("admin_name", "Admin"),
            current_admin=session.get("admin_user_id"),
            add_error=error,
            add_name=name,
            add_uid=uid,
            add_role=role,
        )

    return redirect(url_for("admin.dashboard"))


# ---------------------------------------------------------------------------
# Delete user
# ---------------------------------------------------------------------------

@admin_bp.route("/user/delete", methods=["POST"])
@admin_required
def delete_user():
    uid           = request.form.get("user_id", "").strip()
    current_admin = session.get("admin_user_id")

    if uid == current_admin:
        return redirect(url_for("admin.dashboard"))

    ok = ext.db_manager.delete_user(uid)
    if ok:
        ext.db_manager.log_event(
            "USER_DELETED",
            user_id=uid,
            details={"deleted_by": current_admin},
        )
    return redirect(url_for("admin.dashboard"))


# ---------------------------------------------------------------------------
# Face enrollment
# ---------------------------------------------------------------------------

@admin_bp.route("/enroll/<user_id>")
@admin_required
def enroll(user_id):
    """Show the enrollment webcam page for a specific user."""
    user = ext.db_manager.get_user(user_id)
    if not user:
        return redirect(url_for("admin.dashboard"))

    already_enrolled = ext.db_manager.get_embedding(user_id) is not None

    # Reset enrollment buffer for this session
    session["enroll_user_id"] = user_id
    session["enroll_samples"] = []   # list of base64 face images

    return render_template(
        "admin/enroll.html",
        user=user,
        already_enrolled=already_enrolled,
        samples_needed=ENROLLMENT_SAMPLES,
        min_samples=MIN_ENROLLMENT_SAMPLES,
        admin_name=session.get("admin_name", "Admin"),
    )


@admin_bp.route("/enroll/frame", methods=["POST"])
@admin_required
def enroll_frame():
    """
    Receive one enrollment frame from JS.
    Runs face detection + quality check.
    Returns JSON with result and current sample count.
    """
    data = request.get_json(silent=True)
    if not data or "frame" not in data:
        return jsonify({"error": "No frame data"}), 400

    frame = _decode_frame(data["frame"])
    if frame is None:
        return jsonify({"error": "Could not decode frame"}), 400

    try:
        detection = ext.face_detector.detect_face(frame)
    except Exception as e:
        return jsonify({"error": f"Detection error: {e}"}), 500

    if detection is None:
        return jsonify({
            "accepted":      False,
            "reason":        "No face detected. Move closer to the camera.",
            "sample_count":  len(session.get("enroll_samples", [])),
            "samples_needed": ENROLLMENT_SAMPLES,
        })

    try:
        quality = ext.face_detector.get_face_quality_score(detection["face_image"])
    except Exception:
        quality = 0.0

    if quality < MIN_FACE_QUALITY:
        return jsonify({
            "accepted":      False,
            "reason":        f"Image too blurry (score: {quality:.2f}). Improve lighting.",
            "quality":       round(quality, 2),
            "sample_count":  len(session.get("enroll_samples", [])),
            "samples_needed": ENROLLMENT_SAMPLES,
        })

    # Encode face image as base64 to store in session
    try:
        face_bgr = cv2.cvtColor(detection["face_image"], cv2.COLOR_RGB2BGR)
        _, buf   = cv2.imencode(".jpg", face_bgr, [cv2.IMWRITE_JPEG_QUALITY, 90])
        face_b64 = base64.b64encode(buf).decode()
    except Exception as e:
        return jsonify({"error": f"Encoding error: {e}"}), 500

    samples = session.get("enroll_samples", [])
    samples.append(face_b64)
    session["enroll_samples"] = samples

    return jsonify({
        "accepted":       True,
        "quality":        round(quality, 2),
        "sample_count":   len(samples),
        "samples_needed": ENROLLMENT_SAMPLES,
        "min_samples":    MIN_ENROLLMENT_SAMPLES,
        "face_preview":   face_b64,
    })


@admin_bp.route("/enroll/complete", methods=["POST"])
@admin_required
def enroll_complete():
    """Finalize enrollment -- generate embedding from collected samples."""
    user_id = session.get("enroll_user_id")
    samples_b64 = session.get("enroll_samples", [])

    if not user_id:
        return jsonify({"error": "No enrollment session found."}), 400

    if len(samples_b64) < MIN_ENROLLMENT_SAMPLES:
        return jsonify({
            "error": f"Need at least {MIN_ENROLLMENT_SAMPLES} samples. Got {len(samples_b64)}."
        }), 400

    # Decode all stored face images back to numpy arrays
    face_images = []
    for b64 in samples_b64:
        try:
            img_bytes = base64.b64decode(b64)
            arr       = np.frombuffer(img_bytes, dtype=np.uint8)
            face_bgr  = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            face_rgb  = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2RGB)
            face_images.append(face_rgb)
        except Exception:
            continue

    if len(face_images) < MIN_ENROLLMENT_SAMPLES:
        return jsonify({"error": "Not enough valid face images after decoding."}), 400

    try:
        result = ext.face_recognizer.enroll_user(user_id, face_images)
    except Exception as e:
        return jsonify({"error": f"Enrollment error: {e}"}), 500

    if result["success"]:
        session.pop("enroll_samples", None)
        session.pop("enroll_user_id", None)
        ext.db_manager.log_event(
            "ENROLLED",
            user_id=user_id,
            details={
                "samples_used": result["valid_count"],
                "action":       "face_enrolled",
            },
        )
        return jsonify({
            "success":       True,
            "valid_count":   result["valid_count"],
            "embedding_dim": result["embedding_dim"],
        })
    else:
        return jsonify({
            "success": False,
            "error":   result.get("reason", "Enrollment failed"),
        }), 400


# ---------------------------------------------------------------------------
# Audit logs
# ---------------------------------------------------------------------------

@admin_bp.route("/logs")
@admin_required
def logs():
    limit        = request.args.get("limit", 50, type=int)
    event_filter = request.args.get("filter", "All")

    all_logs = ext.db_manager.get_audit_logs(limit=limit)

    if event_filter != "All":
        filtered = [l for l in all_logs if l.get("event_type") == event_filter]
    else:
        filtered = all_logs

    event_types = [
        "All", "LOGIN_SUCCESS", "LOGIN_FAIL",
        "SPOOF_DETECTED", "ENROLLED", "USER_DELETED", "ADMIN_LOGIN",
    ]

    return render_template(
        "admin/logs.html",
        logs=filtered,
        total=len(all_logs),
        shown=len(filtered),
        event_filter=event_filter,
        event_types=event_types,
        limit=limit,
        admin_name=session.get("admin_name", "Admin"),
    )


@admin_bp.route("/logs/export")
@admin_required
def export_logs():
    """Download all visible logs as CSV."""
    limit        = request.args.get("limit", 50, type=int)
    event_filter = request.args.get("filter", "All")

    all_logs = ext.db_manager.get_audit_logs(limit=limit)
    if event_filter != "All":
        rows = [l for l in all_logs if l.get("event_type") == event_filter]
    else:
        rows = all_logs

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Timestamp", "Event Type", "User ID", "Details"])
    for row in rows:
        writer.writerow([
            row.get("timestamp", ""),
            row.get("event_type", ""),
            row.get("user_id", "") or "",
            row.get("details", "") or "",
        ])

    filename = f"audit_logs_{datetime.now().strftime('%Y%m%d')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
