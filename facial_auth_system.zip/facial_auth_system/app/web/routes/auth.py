"""
app/web/routes/auth.py

Authentication routes using MJPEG video streaming for liveness.
The liveness page shows a live video feed (like cv2.imshow) with
EAR, blink count and EasyShield overlays drawn on each frame.
"""

import cv2
import base64
import numpy as np
from datetime import datetime
from flask import (
    Blueprint, render_template, request,
    session, redirect, url_for, jsonify,
    Response
)
import app.web.extensions as ext
from app.web.video_stream import LivenessSession
from config import LIVENESS_CHECK_FRAMES, SIMILARITY_THRESHOLD

auth_bp = Blueprint("auth", __name__)

# One LivenessSession per server process -- single user at a time.
# For multi-user extend to a dict keyed by session ID.
_liveness_session = None


def _decode_frame(b64_data):
    try:
        if "," in b64_data:
            b64_data = b64_data.split(",")[1]
        img_bytes = base64.b64decode(b64_data)
        arr = np.frombuffer(img_bytes, dtype=np.uint8)
        return cv2.imdecode(arr, cv2.IMREAD_COLOR)
    except Exception as e:
        print(f"[auth] _decode_frame error: {e}")
        return None


def _init_auth_session():
    """Reset all auth-related session keys to defaults."""
    global _liveness_session
    if _liveness_session is not None:
        _liveness_session.stop()
        _liveness_session = None
    session["auth_phase"]        = "idle"
    session["liveness_passed"]   = False
    session["best_face_b64"]     = None
    session["best_face_quality"] = 0.0
    session["denial_reason"]     = ""
    session["auth_user_id"]      = None
    session["auth_user_name"]    = None
    session["auth_confidence"]   = 0.0
    session["auth_similarity"]   = 0.0
    ext.liveness_checker.reset_session()


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@auth_bp.route("/")
def index():
    """Welcome / idle screen."""
    _init_auth_session()
    try:
        users    = ext.db_manager.get_all_users()
        enrolled = sum(
            1 for u in users
            if ext.db_manager.get_embedding(u["user_id"]) is not None
        )
    except Exception:
        enrolled = 0
    return render_template("auth/index.html", enrolled_count=enrolled)


@auth_bp.route("/start", methods=["POST"])
def start():
    """Begin authentication -- reset state and go to liveness."""
    _init_auth_session()
    session["auth_phase"] = "liveness"
    return redirect(url_for("auth.liveness"))


@auth_bp.route("/liveness")
def liveness():
    """Liveness check page -- shows MJPEG video stream."""
    if session.get("auth_phase") != "liveness":
        return redirect(url_for("auth.index"))
    return render_template(
        "auth/liveness.html",
        frames_needed=LIVENESS_CHECK_FRAMES,
    )


@auth_bp.route("/liveness/stream")
def liveness_stream():
    """
    MJPEG stream endpoint.
    The browser <img src="/liveness/stream"> receives this as
    a continuous live video feed -- same as cv2.imshow but in browser.
    """
    global _liveness_session

    # Start a new session if not already running
    if _liveness_session is None or _liveness_session.complete:
        if _liveness_session is not None:
            _liveness_session.stop()
        _liveness_session = LivenessSession(
            face_detector    = ext.face_detector,
            liveness_checker = ext.liveness_checker,
            frames_needed    = LIVENESS_CHECK_FRAMES,
        )

    return Response(
        _liveness_session.generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


@auth_bp.route("/liveness/status")
def liveness_status():
    """
    JSON endpoint polled by liveness.js every 500ms to update
    the stats panel and detect when analysis is complete.
    """
    global _liveness_session
    if _liveness_session is None:
        return jsonify({"error": "No liveness session active"}), 400
    return jsonify(_liveness_session.get_status())


@auth_bp.route("/liveness/complete", methods=["POST"])
def liveness_complete():
    """
    Called by JS once all frames are collected.
    Evaluates liveness verdict and returns redirect URL.
    """
    global _liveness_session

    if _liveness_session is None:
        return jsonify({"redirect": url_for("auth.index")})

    # Save best face image to session before stopping
    if _liveness_session.best_face is not None:
        try:
            face_bgr = cv2.cvtColor(_liveness_session.best_face, cv2.COLOR_RGB2BGR)
            _, buf   = cv2.imencode(".jpg", face_bgr, [cv2.IMWRITE_JPEG_QUALITY, 90])
            session["best_face_b64"]     = base64.b64encode(buf).decode()
            session["best_face_quality"] = float(_liveness_session.best_quality)
        except Exception:
            pass

    try:
        verdict = ext.liveness_checker.is_live()
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    _liveness_session.stop()
    _liveness_session = None

    ext.db_manager.log_event(
        "LIVENESS_PASS" if verdict["live"] else "SPOOF_DETECTED",
        user_id=None,
        details={
            "avg_real_score": verdict["avg_real_score"],
            "total_blinks":   verdict["total_blinks"],
            "frames":         verdict["frames_checked"],
            "reason":         verdict.get("reason", ""),
        },
    )

    if verdict["live"]:
        session["liveness_passed"] = True
        session["auth_phase"]      = "recognition"
        return jsonify({"redirect": url_for("auth.recognize")})
    else:
        session["liveness_passed"] = False
        session["denial_reason"]   = verdict.get("reason", "Liveness check failed")
        session["auth_phase"]      = "denied"
        return jsonify({"redirect": url_for("auth.result")})


@auth_bp.route("/recognize")
def recognize():
    """Run face recognition. Redirects to result page."""
    if session.get("auth_phase") != "recognition":
        return redirect(url_for("auth.index"))

    face_b64 = session.get("best_face_b64")
    if not face_b64:
        session["denial_reason"] = "No face image captured. Please try again."
        session["auth_phase"]    = "denied"
        return redirect(url_for("auth.result"))

    try:
        img_bytes = base64.b64decode(face_b64)
        arr       = np.frombuffer(img_bytes, dtype=np.uint8)
        face_bgr  = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        face_rgb  = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2RGB)
    except Exception as e:
        session["denial_reason"] = f"Face image error: {e}"
        session["auth_phase"]    = "denied"
        return redirect(url_for("auth.result"))

    try:
        result = ext.face_recognizer.identify_user(face_rgb)
    except Exception as e:
        session["denial_reason"] = f"Recognition error: {e}"
        session["auth_phase"]    = "denied"
        return redirect(url_for("auth.result"))

    if result["match"]:
        user_data = ext.db_manager.get_user(result["user_id"]) or {}
        session["auth_phase"]      = "granted"
        session["auth_user_id"]    = result["user_id"]
        session["auth_user_name"]  = user_data.get("name", result["user_id"])
        session["auth_confidence"] = result.get("confidence_pct", 0.0)
        session["auth_similarity"] = result.get("similarity", 0.0)
        ext.db_manager.log_event(
            "LOGIN_SUCCESS",
            user_id=result["user_id"],
            details={
                "similarity":     result.get("similarity", 0.0),
                "confidence_pct": result.get("confidence_pct", 0.0),
            },
        )
    else:
        session["auth_phase"]    = "denied"
        session["denial_reason"] = result.get("reason", "Face not recognized")
        ext.db_manager.log_event(
            "LOGIN_FAIL",
            user_id=None,
            details={
                "reason":     result.get("reason"),
                "similarity": result.get("similarity", 0.0),
            },
        )

    return redirect(url_for("auth.result"))


@auth_bp.route("/result")
def result():
    """Show the final access granted or denied screen."""
    phase = session.get("auth_phase", "idle")
    if phase not in ("granted", "denied"):
        return redirect(url_for("auth.index"))

    return render_template(
        "auth/result.html",
        phase=phase,
        user_name=session.get("auth_user_name", ""),
        user_id=session.get("auth_user_id", ""),
        confidence=session.get("auth_confidence", 0.0),
        similarity=session.get("auth_similarity", 0.0),
        similarity_threshold=SIMILARITY_THRESHOLD,
        denial_reason=session.get("denial_reason", ""),
        timestamp=datetime.now().strftime("%d %b %Y  %H:%M:%S"),
    )


@auth_bp.route("/reset", methods=["POST", "GET"])
def reset():
    """Reset all auth state and return to welcome screen."""
    _init_auth_session()
    return redirect(url_for("auth.index"))




































