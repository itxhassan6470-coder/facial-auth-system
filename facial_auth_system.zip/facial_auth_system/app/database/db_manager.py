"""
db_manager.py

DatabaseManager handles all database operations for the Facial
Biometric Authentication System: user management, embedding storage,
and audit logging.
"""

import json
import sqlite3
from pathlib import Path

import numpy as np


class DatabaseManager:
    """
    Manages all SQLite database operations for the facial authentication
    system, including users, embeddings, and audit logs.
    """

    def __init__(self, db_path):
        """
        Initialize the DatabaseManager, connect to the SQLite database,
        create tables if they don't exist, and ensure a default admin
        user is present.

        Args:
            db_path (str or Path): Path to the SQLite database file.
        """
        try:
            self.db_path = Path(db_path)
            self.db_path.parent.mkdir(parents=True, exist_ok=True)

            self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self.conn.row_factory = sqlite3.Row

            self._initialize_db()
            self._create_default_admin()
        except Exception as e:
            print(f"[DatabaseManager.__init__] Error initializing database: {e}")
            raise

    def _initialize_db(self):
        """
        Read schema.sql and execute it to create all required tables
        if they do not already exist.
        """
        try:
            schema_path = Path(__file__).resolve().parent / "schema.sql"
            with open(schema_path, "r") as f:
                schema_sql = f.read()

            self.conn.executescript(schema_sql)
            self.conn.commit()
        except Exception as e:
            print(f"[DatabaseManager._initialize_db] Error creating tables: {e}")
            raise

    def _create_default_admin(self):
        """
        Create a default admin user (ADMIN-001) if no admin user
        currently exists in the database.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT COUNT(*) AS count FROM users WHERE role = ?",
                ("admin",),
            )
            row = cursor.fetchone()

            if row["count"] == 0:
                self.add_user(name="Admin", user_id="ADMIN-001", role="admin")
        except Exception as e:
            print(f"[DatabaseManager._create_default_admin] Error creating default admin: {e}")

    def add_user(self, name, user_id, role="user") -> bool:
        """
        Insert a new user record into the users table.

        Args:
            name (str): Full name of the user.
            user_id (str): Unique identifier for the user (e.g. "STU-001").
            role (str): "admin" or "user" (default "user").

        Returns:
            bool: True if the user was added successfully, False if the
            user_id already exists or an error occurred.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "INSERT INTO users (name, user_id, role) VALUES (?, ?, ?)",
                (name, user_id, role),
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            # user_id already exists (UNIQUE constraint violation)
            return False
        except Exception as e:
            print(f"[DatabaseManager.add_user] Error adding user: {e}")
            return False

    def delete_user(self, user_id) -> bool:
        """
        Soft-delete a user by setting is_active = 0, preserving the
        audit trail. Also removes their stored face embedding so they
        cannot authenticate after being deactivated.

        Args:
            user_id (str): Unique identifier of the user to delete.

        Returns:
            bool: True if a user was found and deactivated, False otherwise.
        """
        try:
            cursor = self.conn.cursor()

            # Soft-delete the user record (preserves audit trail)
            cursor.execute(
                "UPDATE users SET is_active = 0 WHERE user_id = ?",
                (user_id,),
            )
            affected = cursor.rowcount

            # Remove embedding so deleted user cannot authenticate
            cursor.execute(
                "DELETE FROM embeddings WHERE user_id = ?",
                (user_id,),
            )

            self.conn.commit()
            return affected > 0
        except Exception as e:
            print(f"[DatabaseManager.delete_user] Error deleting user: {e}")
            return False

    def get_user(self, user_id):
        """
        Retrieve a single user record by user_id.

        Args:
            user_id (str): Unique identifier of the user.

        Returns:
            dict or None: User record as a dictionary, or None if not found.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT * FROM users WHERE user_id = ?",
                (user_id,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None
        except Exception as e:
            print(f"[DatabaseManager.get_user] Error retrieving user: {e}")
            return None

    def get_all_users(self):
        """
        Retrieve all active users.

        Returns:
            list[dict]: List of active user records as dictionaries.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT * FROM users WHERE is_active = 1 ORDER BY created_at ASC"
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            print(f"[DatabaseManager.get_all_users] Error retrieving users: {e}")
            return []

    def save_embedding(self, user_id, embedding_array: np.ndarray) -> bool:
        """
        Save a facial embedding for a user, replacing any existing
        embedding for that user.

        Args:
            user_id (str): Unique identifier of the user.
            embedding_array (np.ndarray): The embedding vector.

        Returns:
            bool: True on success, False on failure.
        """
        try:
            embedding_bytes = embedding_array.astype(np.float32).tobytes()

            cursor = self.conn.cursor()
            # Remove any existing embedding for this user first
            cursor.execute(
                "DELETE FROM embeddings WHERE user_id = ?",
                (user_id,),
            )
            cursor.execute(
                "INSERT INTO embeddings (user_id, embedding) VALUES (?, ?)",
                (user_id, embedding_bytes),
            )
            self.conn.commit()
            return True
        except Exception as e:
            print(f"[DatabaseManager.save_embedding] Error saving embedding: {e}")
            return False

    def get_embedding(self, user_id):
        """
        Retrieve and deserialize the embedding for a given user.

        Args:
            user_id (str): Unique identifier of the user.

        Returns:
            np.ndarray or None: The embedding vector, or None if not found.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT embedding FROM embeddings WHERE user_id = ? "
                "ORDER BY created_at DESC LIMIT 1",
                (user_id,),
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return np.frombuffer(row["embedding"], dtype=np.float32)
        except Exception as e:
            print(f"[DatabaseManager.get_embedding] Error retrieving embedding: {e}")
            return None

    def get_all_embeddings(self):
        """
        Retrieve all stored embeddings, used for comparing against all
        users during authentication.

        Returns:
            list[dict]: List of {"user_id": str, "embedding": np.ndarray}.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT user_id, embedding FROM embeddings")
            rows = cursor.fetchall()

            results = []
            for row in rows:
                results.append(
                    {
                        "user_id": row["user_id"],
                        "embedding": np.frombuffer(row["embedding"], dtype=np.float32),
                    }
                )
            return results
        except Exception as e:
            print(f"[DatabaseManager.get_all_embeddings] Error retrieving embeddings: {e}")
            return []

    def log_event(self, event_type, user_id=None, details=None) -> None:
        """
        Insert a record into the audit_logs table.

        Args:
            event_type (str): Type of event, e.g. "LOGIN_SUCCESS",
                "LOGIN_FAIL", "SPOOF_DETECTED", "ENROLLED",
                "USER_DELETED", "ADMIN_LOGIN".
            user_id (str, optional): Associated user_id, or None if unknown.
            details (dict, optional): Extra information, serialized to JSON.

        Returns:
            None
        """
        try:
            details_json = json.dumps(details) if details is not None else None

            cursor = self.conn.cursor()
            cursor.execute(
                "INSERT INTO audit_logs (user_id, event_type, details) "
                "VALUES (?, ?, ?)",
                (user_id, event_type, details_json),
            )
            self.conn.commit()
        except Exception as e:
            print(f"[DatabaseManager.log_event] Error logging event: {e}")

    def get_audit_logs(self, limit=100):
        """
        Retrieve the most recent audit log records.

        Args:
            limit (int): Maximum number of records to return (default 100).

        Returns:
            list[dict]: Audit log records, ordered by timestamp DESC.
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute(
                "SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?",
                (limit,),
            )
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            print(f"[DatabaseManager.get_audit_logs] Error retrieving audit logs: {e}")
            return []

    def close(self):
        """
        Close the underlying SQLite database connection.
        """
        try:
            self.conn.close()
        except Exception as e:
            print(f"[DatabaseManager.close] Error closing connection: {e}")
