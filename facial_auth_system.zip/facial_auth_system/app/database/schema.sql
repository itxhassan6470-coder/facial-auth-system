-- schema.sql
-- Database schema for Facial Biometric Authentication System
-- Module 1: Project Setup and Database

-- TABLE: users
-- Stores registered users (admins and regular users)
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    user_id     TEXT UNIQUE NOT NULL,
    role        TEXT NOT NULL DEFAULT 'user',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active   INTEGER DEFAULT 1
);

-- TABLE: embeddings
-- Stores facial embeddings (as raw numpy bytes) linked to a user
CREATE TABLE IF NOT EXISTS embeddings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT NOT NULL,
    embedding   BLOB NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- TABLE: audit_logs
-- Stores authentication/system events for auditing purposes
CREATE TABLE IF NOT EXISTS audit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     TEXT,
    event_type  TEXT NOT NULL,
    details     TEXT,
    timestamp   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
