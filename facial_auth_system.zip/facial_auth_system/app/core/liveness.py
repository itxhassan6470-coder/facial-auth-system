"""
app/core/liveness.py

Module 4: Liveness Detection
------------------------------
Combines two independent anti-spoofing strategies:

  1. BlinkDetector  — Eye Aspect Ratio (EAR) blink detection using
                      dlib 68-point facial landmarks from Module 2.
                      Proves a live face by detecting a real blink.

  2. EasyShieldAntiSpoof — YOLOv12-based CNN anti-spoofing using
                      the EasyShield V2.5 model (best.pt).
                      Classifies each face crop as real or fake.

  3. LivenessChecker — Orchestrates both checks across a session of
                      N frames and delivers a single is_live() verdict.

IMPORTANT — EasyShield result parsing
--------------------------------------
EasyShield V2.5 can be either a CLASSIFICATION model (outputs
result[0].probs) or a DETECTION model (outputs result[0].boxes).
Run inspect_easyshield.py first and paste its output to Claude to
confirm which branch applies to your downloaded weights.

Two branches are written below, each clearly labelled.
Activate the correct one by following the inline instructions.

Dependencies:
    pip install ultralytics opencv-python numpy
    DO NOT install tensorflow — it is not used here.

Model file:
    Place best.pt at: models/best.pt
    Download from: https://github.com/mahostar/EasyShield_v2.5
    Navigate to: EasyShield weights / EasyShield V2.5 - nano
                 (well mixed dataset) 120 epochs 16 batch / weights/
"""

import numpy as np
import cv2

from config import (
    BLINK_EAR_THRESHOLD,
    BLINK_CONSEC_FRAMES,
    EASYSHIELD_MODEL_PATH,
    EASYSHIELD_CONF_THRESHOLD,
    REQUIRE_BLINK,
    LIVENESS_CHECK_FRAMES,
    FACE_IMAGE_SIZE,
)


# ══════════════════════════════════════════════════════════════════════
# CLASS 1: BlinkDetector
# ══════════════════════════════════════════════════════════════════════

class BlinkDetector:
    """
    Detects eye blinks using the Eye Aspect Ratio (EAR) computed from
    dlib's 68-point facial landmarks.

    The EAR drops sharply when an eye closes and rises again when it
    reopens. A blink is counted when the EAR stays below the threshold
    for at least BLINK_CONSEC_FRAMES consecutive frames, then rises
    above it again.

    This class has zero dependencies outside numpy and config.py.
    """

    def __init__(self):
        """
        Initialise blink state. Call reset_session() before every new
        authentication attempt.
        """
        self.ear_threshold  = BLINK_EAR_THRESHOLD
        self.consec_frames  = BLINK_CONSEC_FRAMES

        self.consec_frames_below_threshold  = 0
        self.total_blinks                   = 0
        self.blink_detected_this_session    = False

    # ── Core EAR calculation ──────────────────────────────────────────

    def calculate_ear(self, eye_points: list) -> float:
        
        if len(eye_points) != 6:
            print(f"[BlinkDetector] WARNING: expected 6 eye points, got {len(eye_points)}. "
                  "Returning default EAR 0.3.")
            return 0.3

        p = [np.array(pt, dtype=np.float64) for pt in eye_points]

        A = np.linalg.norm(p[1] - p[5])   # p2 - p6
        B = np.linalg.norm(p[2] - p[4])   # p3 - p5
        C = np.linalg.norm(p[0] - p[3])   # p1 - p4

        if C < 1e-6:
            # Degenerate horizontal extent (e.g. all points on same x).
            return 0.0

        return float((A + B) / (2.0 * C))

    # ── Per-frame processing ──────────────────────────────────────────

    def process_frame(self, eye_landmarks_dict: dict) -> dict:
        """
        Update blink state from the current frame's eye landmarks.

        Args:
            eye_landmarks_dict (dict): Output of
                FaceDetector.get_eye_landmarks(), with keys
                "left_eye" and "right_eye", each a list of 6 (x,y) tuples.

        Returns:
            dict: {
                "left_ear":       float,
                "right_ear":      float,
                "avg_ear":        float,
                "total_blinks":   int,
                "blink_detected": bool,   # True if ≥1 blink this session
                "eye_closed_now": bool    # True if currently below threshold
            }
        """
        left_ear  = self.calculate_ear(eye_landmarks_dict["left_eye"])
        right_ear = self.calculate_ear(eye_landmarks_dict["right_eye"])
        avg_ear   = (left_ear + right_ear) / 2.0

        return self._update_state(avg_ear, left_ear, right_ear)

    def _update_state(self, avg_ear: float,
                      left_ear: float = 0.0,
                      right_ear: float = 0.0) -> dict:
        """
        Run the blink state machine on a single avg_ear value.
        Shared by process_frame() and the test-only helper below.
        """
        if avg_ear < self.ear_threshold:
            self.consec_frames_below_threshold += 1
            eye_closed_now = True
        else:
            if self.consec_frames_below_threshold >= self.consec_frames:
                self.total_blinks += 1
                self.blink_detected_this_session = True
            self.consec_frames_below_threshold = 0
            eye_closed_now = False

        return {
            "left_ear":       float(left_ear),
            "right_ear":      float(right_ear),
            "avg_ear":        float(avg_ear),
            "total_blinks":   self.total_blinks,
            "blink_detected": self.blink_detected_this_session,
            "eye_closed_now": eye_closed_now,
        }

    # ── Test-only helper ──────────────────────────────────────────────

    def process_frame_with_ear(self, avg_ear: float) -> dict:
        """
        TEST-ONLY: bypass landmark calculation and drive the blink
        state machine directly with a pre-computed avg_ear value.

        Do NOT call this from production code — use process_frame().

        Args:
            avg_ear (float): Simulated average EAR value.

        Returns:
            dict: Same structure as process_frame().
        """
        return self._update_state(avg_ear)

    # ── Session management ────────────────────────────────────────────

    def reset_session(self) -> None:
        """
        Reset all blink counters. Call before every new authentication
        attempt to avoid carrying over state from a previous session.
        """
        self.consec_frames_below_threshold  = 0
        self.total_blinks                   = 0
        self.blink_detected_this_session    = False


# ══════════════════════════════════════════════════════════════════════
# CLASS 2: EasyShieldAntiSpoof
# ══════════════════════════════════════════════════════════════════════

class EasyShieldAntiSpoof:
    """
    YOLOv12-based face anti-spoofing using the EasyShield V2.5 model.

    FAIL-SAFE DESIGN: any exception, missing model, or ambiguous result
    is treated as FAKE. The system never silently passes a spoof.

    Requires: pip install ultralytics
    Model file: models/best.pt  (download from EasyShield GitHub)
    """

    def __init__(self):
        """
        Load the EasyShield model and run a warm-up inference.

        Raises:
            FileNotFoundError: If best.pt is not in MODELS_DIR.
            RuntimeError: If ultralytics cannot be imported.
        """
        try:
            from ultralytics import YOLO
            self._YOLO = YOLO
        except ImportError:
            raise RuntimeError(
                "ultralytics is not installed.\n"
                "  Run: pip install ultralytics\n"
            )

        if not EASYSHIELD_MODEL_PATH.exists():
            raise FileNotFoundError(
                f"\nEasyShield model not found at: {EASYSHIELD_MODEL_PATH}\n\n"
                "Download best.pt from:\n"
                "  https://github.com/mahostar/EasyShield_v2.5\n"
                "Navigate to:\n"
                "  EasyShield weights / EasyShield V2.5 - nano\n"
                "  (well mixed dataset) 120 epochs 16 batch / weights/\n"
                f"Place best.pt at: {EASYSHIELD_MODEL_PATH}\n"
            )

        self.model        = self._YOLO(str(EASYSHIELD_MODEL_PATH))
        self.class_names  = self.model.names   # e.g. {0: 'fake', 1: 'real'}

        # Resolve real / fake class indices from model.names dynamically
        # so this works regardless of which order the model was trained with.
        real_keys = [k for k, v in self.class_names.items() if v.lower() == "real"]
        fake_keys = [k for k, v in self.class_names.items() if v.lower() == "fake"]

        if not real_keys or not fake_keys:
            raise ValueError(
                f"Expected class names containing 'real' and 'fake'. "
                f"Got: {self.class_names}"
            )

        self.real_class_idx = real_keys[0]
        self.fake_class_idx = fake_keys[0]

        # Warm-up: compile model graph before first real prediction.
        dummy = np.zeros((FACE_IMAGE_SIZE, FACE_IMAGE_SIZE, 3), dtype=np.uint8)
        self.model.predict(dummy, verbose=False)

        print("EasyShield anti-spoofing model loaded successfully")
        print(f"  Classes          : {self.class_names}")
        print(f"  Real class index : {self.real_class_idx}")

    # ── Shared fail-safe response ─────────────────────────────────────

    @staticmethod
    def _fail_safe(error_msg: str = "") -> dict:
        """Return a fail-safe FAKE response on any error."""
        result = {
            "is_real":    False,
            "real_score": 0.0,
            "fake_score": 1.0,
            "raw_label":  "error",
        }
        if error_msg:
            result["error"] = error_msg
        return result

    # ── Primary prediction method ─────────────────────────────────────

    def predict(self, face_image_rgb: np.ndarray) -> dict:
        """
        Classify a face image as real or fake.

        Args:
            face_image_rgb (np.ndarray | None): 160×160 RGB uint8 array,
                as returned in FaceDetector.detect_face()["face_image"].

        Returns:
            dict: {
                "is_real":    bool,   # True = classified as genuine
                "real_score": float,  # 0.0-1.0 confidence for real
                "fake_score": float,  # 1.0 - real_score
                "raw_label":  str     # "real", "fake", or "error"
            }
            On any error: fail-safe dict with is_real=False.
        """
        if face_image_rgb is None or not isinstance(face_image_rgb, np.ndarray):
            return self._fail_safe("Input is None or not a numpy array")

        try:
            bgr_image = cv2.cvtColor(face_image_rgb, cv2.COLOR_RGB2BGR)

            results = self.model.predict(
                bgr_image,
                verbose=False,
                conf=EASYSHIELD_CONF_THRESHOLD,
            )

            return self._parse_result(results)

        except Exception as exc:
            print(f"[EasyShieldAntiSpoof] predict() exception: {exc}")
            return self._fail_safe(str(exc))

    def _parse_result(self, results) -> dict:
        """
        Parse the ultralytics Results object for EasyShield V2.5.

        ── Confirmed model format (from inspect_easyshield.py) ──────
        Model type  : DETECTION  (result[0].boxes, no result[0].probs)
        Class names : {0: 'real', 1: 'fake'}
        Real index  : 0
        Fake index  : 1

        Behaviour on a REAL face: boxes contains one high-confidence
        detection, class_id=0 ('real'), conf ~ 0.7-0.99.

        Behaviour on a FAKE / spoof: boxes contains one detection,
        class_id=1 ('fake'), conf ~ 0.7-0.99.

        Behaviour on a BLANK / no-face image: boxes tensor is empty
        (0 detections). This is treated as FAKE (fail-safe).
        ─────────────────────────────────────────────────────────────
        """
        try:
            result = results[0]

            # ── Detection model — EasyShield V2.5 (ACTIVE BRANCH) ────
            if result.boxes is not None and len(result.boxes) > 0:
                # Pick the detection with the highest confidence score.
                best_box   = max(result.boxes, key=lambda b: float(b.conf[0]))
                class_id   = int(best_box.cls[0])
                conf       = float(best_box.conf[0])
                label      = self.model.names.get(class_id, "unknown").lower()
                is_real    = (label == "real")
                # Normalise to a real_score in [0, 1]:
                # If labelled 'real' the confidence IS the real score.
                # If labelled 'fake' the confidence is the fake score,
                # so real_score = 1 - conf.
                real_score = conf if is_real else (1.0 - conf)
                fake_score = 1.0 - real_score

                return {
                    "is_real":    is_real,
                    "real_score": real_score,
                    "fake_score": fake_score,
                    "raw_label":  label,
                }

            # ── No detections (blank frame / no face found) ───────────
            # Fail-safe: no detection = cannot confirm liveness = FAKE.
            # This is the expected result for a blank/all-zero test image.
            return {
                "is_real":    False,
                "real_score": 0.0,
                "fake_score": 1.0,
                "raw_label":  "unknown",
            }

        except Exception as exc:
            print(f"[EasyShieldAntiSpoof] _parse_result() exception: {exc}")
            return self._fail_safe(str(exc))

    # ── Convenience: predict directly from full frame + bbox ─────────

    def predict_from_frame(self, frame: np.ndarray, bbox: tuple) -> dict:
        """
        Crop a face from a full BGR frame and run anti-spoof prediction.

        Useful when the caller already has the raw frame and bbox and
        wants to avoid maintaining a separate face_image crop.

        Args:
            frame (np.ndarray): Full BGR frame from cv2.VideoCapture.
            bbox (tuple): (x, y, w, h) bounding box in frame coordinates.

        Returns:
            dict: Same structure as predict().
        """
        try:
            x, y, w, h = bbox
            fh, fw     = frame.shape[:2]

            # Clamp bbox to frame bounds.
            x1 = max(0, x)
            y1 = max(0, y)
            x2 = min(fw, x + w)
            y2 = min(fh, y + h)

            crop_bgr = frame[y1:y2, x1:x2]
            if crop_bgr.size == 0:
                return self._fail_safe("Empty crop from bbox")

            crop_bgr = cv2.resize(
                crop_bgr,
                (FACE_IMAGE_SIZE, FACE_IMAGE_SIZE),
                interpolation=cv2.INTER_AREA,
            )
            # predict() expects RGB
            crop_rgb = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2RGB)
            return self.predict(crop_rgb)

        except Exception as exc:
            print(f"[EasyShieldAntiSpoof] predict_from_frame() exception: {exc}")
            return self._fail_safe(str(exc))


# ══════════════════════════════════════════════════════════════════════
# CLASS 3: LivenessChecker
# ══════════════════════════════════════════════════════════════════════

class LivenessChecker:
    """
    Orchestrates blink detection and anti-spoofing across a session of
    video frames and delivers a single is_live() verdict.

    Typical usage per authentication attempt:
        checker.reset_session()
        for frame in capture_N_frames():
            detection = detector.detect_face(frame)
            checker.check_frame(frame, detection)
        verdict = checker.is_live()
    """

    def __init__(self, face_detector):
        """
        Args:
            face_detector: An initialized FaceDetector instance
                (from app.core.face_detector). Injected to keep
                this class testable and decoupled.
        """
        self.face_detector = face_detector
        self.blink_detector = BlinkDetector()
        self.anti_spoof     = EasyShieldAntiSpoof()

        # Per-session accumulators — reset with reset_session()
        self._spoof_scores   = []   # float real_score per frame
        self._blink_results  = []   # blink dict per frame

    def reset_session(self) -> None:
        """
        Clear all session accumulators and blink counters.
        MUST be called before every new authentication attempt.
        """
        self.blink_detector.reset_session()
        self._spoof_scores  = []
        self._blink_results = []

    def check_frame(self, frame: np.ndarray, detection_result) -> dict:
        """
        Process a single frame: run blink detection and anti-spoof check.

        Args:
            frame (np.ndarray): Raw BGR frame from cv2.VideoCapture.
            detection_result (dict | None): Output of
                FaceDetector.detect_face(). Pass None if no face found.

        Returns:
            dict: {"face_present": False} if no face, otherwise:
                {
                    "face_present":   True,
                    "left_ear":       float,
                    "right_ear":      float,
                    "avg_ear":        float,
                    "eye_closed_now": bool,
                    "total_blinks":   int,
                    "blink_detected": bool,
                    "cnn_is_real":    bool,
                    "cnn_real_score": float,
                    "cnn_raw_label":  str
                }
        """
        if detection_result is None:
            return {"face_present": False}

        # ── Step 1: Blink ─────────────────────────────────────────────
        eye_lm      = self.face_detector.get_eye_landmarks(
                          detection_result["landmarks"])
        blink_result = self.blink_detector.process_frame(eye_lm)
        self._blink_results.append(blink_result)

        # ── Step 2: Anti-spoof ────────────────────────────────────────
        spoof_result = self.anti_spoof.predict(detection_result["face_image"])
        self._spoof_scores.append(spoof_result["real_score"])

        return {
            "face_present":   True,
            "left_ear":       blink_result["left_ear"],
            "right_ear":      blink_result["right_ear"],
            "avg_ear":        blink_result["avg_ear"],
            "eye_closed_now": blink_result["eye_closed_now"],
            "total_blinks":   blink_result["total_blinks"],
            "blink_detected": blink_result["blink_detected"],
            "cnn_is_real":    spoof_result["is_real"],
            "cnn_real_score": spoof_result["real_score"],
            "cnn_raw_label":  spoof_result["raw_label"],
        }

    def get_session_summary(self) -> dict:
        """
        Aggregate statistics across all frames in the current session.

        Returns:
            dict: {
                "frames_checked":  int,
                "avg_real_score":  float,
                "spoof_pass":      bool,   # avg_real_score >= threshold
                "blink_pass":      bool,   # at least 1 blink detected
                "total_blinks":    int
            }
        """
        n = len(self._spoof_scores)
        avg_score  = float(np.mean(self._spoof_scores)) if n > 0 else 0.0
        spoof_pass = avg_score >= EASYSHIELD_CONF_THRESHOLD

        return {
            "frames_checked": n,
            "avg_real_score": avg_score,
            "spoof_pass":     spoof_pass,
            "blink_pass":     self.blink_detector.blink_detected_this_session,
            "total_blinks":   self.blink_detector.total_blinks,
        }

    def is_live(self, require_blink: bool = None) -> dict:
        """
        Deliver the final liveness verdict for the current session.

        Args:
            require_blink (bool | None): Override the REQUIRE_BLINK
                config value. Pass None to use the config default.

        Returns:
            dict: {
                "live":           bool,
                "spoof_pass":     bool,
                "blink_pass":     bool,
                "avg_real_score": float,
                "total_blinks":   int,
                "frames_checked": int,
                "reason":         str   # human-readable explanation
            }
        """
        if require_blink is None:
            require_blink = REQUIRE_BLINK

        summary    = self.get_session_summary()
        spoof_pass = summary["spoof_pass"]
        blink_pass = summary["blink_pass"] if require_blink else True

        live = spoof_pass and blink_pass

        # Build a clear human-readable reason.
        if live:
            reason = "Liveness check passed"
        elif not spoof_pass and not blink_pass:
            reason = (
                f"Spoof detected (real_score: {summary['avg_real_score']:.2f}) "
                f"and blink not detected"
            )
        elif not spoof_pass:
            reason = (
                f"Spoof detected (real_score: {summary['avg_real_score']:.2f}, "
                f"threshold: {EASYSHIELD_CONF_THRESHOLD})"
            )
        else:  # not blink_pass
            reason = "Blink not detected during liveness window"

        return {
            "live":           live,
            "spoof_pass":     spoof_pass,
            "blink_pass":     blink_pass,
            "avg_real_score": summary["avg_real_score"],
            "total_blinks":   summary["total_blinks"],
            "frames_checked": summary["frames_checked"],
            "reason":         reason,
        }
