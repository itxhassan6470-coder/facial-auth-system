"""
app/core/face_recognizer.py

Module 3: Face Recognition & Embedding
---------------------------------------
Generates, stores, and compares 128-dimensional Facenet embeddings
for facial biometric authentication.

Responsibilities:
  - ENROLLMENT : generate an average embedding from multiple
                 face samples and persist it via DatabaseManager.
  - AUTHENTICATION : compare a live face embedding against every
                     stored embedding (identify_user) or against a
                     single claimed identity (verify_user).

This class is completely independent of liveness detection
(Module 4). It only ever receives an already-verified face_image
— a 160×160 RGB numpy array — and knows nothing about how that
image was acquired or whether a blink was detected.

Dependencies:
  pip install deepface  (pulls in tensorflow/keras automatically)

DeepFace will download the Facenet weights (~90 MB) on first use
if they are not already cached in ~/.deepface/weights/.
"""

import numpy as np

from config import (
    EMBEDDING_DIM,
    SIMILARITY_THRESHOLD,
    ENROLLMENT_SAMPLES,
    FACE_IMAGE_SIZE,
    FACE_MODEL_NAME,
    MIN_ENROLLMENT_SAMPLES,
)
from app.utils.helpers import (
    l2_normalize,
    cosine_similarity,
    is_match,
)


class FaceRecognizer:
    """
    Handles face embedding generation (via DeepFace/Facenet),
    user enrollment, and identity verification.

    Args:
        db_manager: A DatabaseManager instance that provides
            save_embedding(), get_embedding(), get_all_embeddings(),
            and log_event(). Injected at construction time so this
            class remains testable without a real database.
    """

    def __init__(self, db_manager):
        """
        Initialize the recognizer: load the Facenet model and warm
        it up with a single dummy inference so the first real
        authentication call is not penalised by model loading time.

        Args:
            db_manager: DatabaseManager instance (from Module 1).

        Raises:
            RuntimeError: If DeepFace or TensorFlow cannot be
                imported. The error message includes install guidance.
        """
        try:
            from deepface import DeepFace as _DeepFace  # local import keeps
            self._DeepFace = _DeepFace                  # module-level namespace clean
        except ImportError:
            raise RuntimeError(
                "DeepFace is not installed. Run:\n"
                "    pip install deepface\n"
                "DeepFace will also need tensorflow; install it with:\n"
                "    pip install tensorflow\n"
            )

        self.db_manager = db_manager
        self.model_name = FACE_MODEL_NAME  # "Facenet"

        # Warm-up: trigger model download/load once at startup.
        print("Loading Facenet model (downloading weights on first run)…")
        self._warmup()
        print("Face recognizer initialized (Facenet)")

    # ──────────────────────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────────────────────

    def _warmup(self):
        """
        Run one silent inference on a blank frame so the Keras/TF
        model graph is compiled before real authentication begins.

        Failures here are suppressed: a slow first authentication
        is preferable to crashing during __init__.
        """
        dummy = np.zeros((FACE_IMAGE_SIZE, FACE_IMAGE_SIZE, 3), dtype=np.uint8)
        try:
            self._DeepFace.represent(
                img_path=dummy,
                model_name=self.model_name,
                enforce_detection=False,
                detector_backend="skip",
            )
        except Exception:
            pass  # warm-up failure is non-fatal

    def _call_deepface(self, face_image: np.ndarray):
        """
        Run DeepFace.represent() with the project-standard parameters.

        Args:
            face_image (np.ndarray): 160×160 RGB uint8 array.

        Returns:
            list | None: Raw DeepFace result list, or None on any error.
        """
        try:
            result = self._DeepFace.represent(
                img_path=face_image,
                model_name=self.model_name,
                enforce_detection=False,   # face already detected upstream
                detector_backend="skip",   # skip DeepFace's own detector
            )
            return result
        except Exception as exc:
            print(f"[FaceRecognizer] DeepFace.represent() failed: {exc}")
            return None

    # ──────────────────────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────────────────────

    def generate_embedding(self, face_image: np.ndarray):
        """
        Generate an L2-normalized Facenet embedding for a single face.

        Args:
            face_image (np.ndarray): 160×160 RGB numpy array (uint8),
                as returned in FaceDetector.detect_face()["face_image"].

        Returns:
            np.ndarray | None: Float32 array of shape (128,), normalized
            to unit length. Returns None if DeepFace raises any exception
            or returns an empty / malformed result.
        """
        result = self._call_deepface(face_image)

        if not result:
            print("[FaceRecognizer] generate_embedding: empty result from DeepFace")
            return None

        try:
            raw = np.array(result[0]["embedding"], dtype=np.float32)
        except (KeyError, IndexError, TypeError) as exc:
            print(f"[FaceRecognizer] generate_embedding: could not parse result — {exc}")
            return None

        return l2_normalize(raw)

    def enroll_user(self, user_id: str, face_images_list: list) -> dict:
        """
        Enroll a new user by computing an average embedding from
        multiple face samples.

        The average is L2-re-normalized before storage so it remains
        a proper unit vector for cosine comparison.

        Args:
            user_id (str): Unique identifier for the user.
            face_images_list (list[np.ndarray]): List of 160×160 RGB
                numpy arrays. Expects ENROLLMENT_SAMPLES (10) images,
                but at least MIN_ENROLLMENT_SAMPLES (5) must produce
                a valid embedding.

        Returns:
            dict: On success —
                  {"success": True,
                   "valid_count": int,
                   "embedding_dim": int}
                  On failure —
                  {"success": False,
                   "reason": str,
                   "valid_count": int}
        """
        valid_embeddings = []

        for idx, img in enumerate(face_images_list):
            emb = self.generate_embedding(img)
            if emb is not None:
                valid_embeddings.append(emb)
            else:
                print(f"[FaceRecognizer] enroll_user: skipping image {idx} (bad embedding)")

        valid_count = len(valid_embeddings)

        if valid_count < MIN_ENROLLMENT_SAMPLES:
            return {
                "success": False,
                "reason": "Not enough valid embeddings",
                "valid_count": valid_count,
            }

        # Average then re-normalize so the stored vector is still unit-length.
        avg_embedding = np.mean(valid_embeddings, axis=0).astype(np.float32)
        avg_embedding = l2_normalize(avg_embedding)

        saved = self.db_manager.save_embedding(user_id, avg_embedding)
        if not saved:
            return {
                "success": False,
                "reason": "Database write failed",
                "valid_count": valid_count,
            }

        self.db_manager.log_event(
            "ENROLLED",
            user_id,
            {"samples_used": valid_count, "model": self.model_name},
        )

        return {
            "success": True,
            "valid_count": valid_count,
            "embedding_dim": len(avg_embedding),
        }

    def identify_user(self, face_image: np.ndarray) -> dict:
        """
        1:N identification — compare a live face against every stored
        embedding and return the best match.

        This method does NOT perform liveness checking. It assumes the
        caller has already verified the face is genuine.

        Args:
            face_image (np.ndarray): 160×160 RGB numpy array.

        Returns:
            dict: On confirmed match —
                  {"match": True,
                   "user_id": str,
                   "similarity": float,
                   "confidence_pct": float}
                  On no match —
                  {"match": False,
                   "similarity": float,  # best score seen (may be absent)
                   "reason": str}
        """
        live_emb = self.generate_embedding(face_image)
        if live_emb is None:
            return {"match": False, "reason": "Embedding failed"}

        all_records = self.db_manager.get_all_embeddings()
        if not all_records:
            return {"match": False, "reason": "No enrolled users"}

        best_score = -1.0
        best_user_id = None

        for record in all_records:
            stored_emb = record["embedding"]

            # Guard against dimension mismatch between stored and live embeddings.
            if stored_emb.shape != live_emb.shape:
                print(
                    f"[FaceRecognizer] identify_user: dimension mismatch for "
                    f"user {record['user_id']} "
                    f"(stored {stored_emb.shape} vs live {live_emb.shape}) — skipping"
                )
                continue

            score = cosine_similarity(live_emb, stored_emb)
            if score > best_score:
                best_score = score
                best_user_id = record["user_id"]

        if best_score < 0:
            # Every stored embedding had a dimension mismatch.
            return {"match": False, "reason": "No comparable embeddings found"}

        if is_match(best_score, SIMILARITY_THRESHOLD):
            return {
                "match": True,
                "user_id": best_user_id,
                "similarity": float(best_score),
                "confidence_pct": round(best_score * 100, 1),
            }

        return {
            "match": False,
            "similarity": float(best_score),
            "reason": "No match found",
        }

    def verify_user(self, face_image: np.ndarray, claimed_user_id: str) -> dict:
        """
        1:1 verification — compare a live face against a single
        claimed identity's stored embedding. Faster than identify_user()
        because only one comparison is made.

        Args:
            face_image (np.ndarray): 160×160 RGB numpy array.
            claimed_user_id (str): The user_id the person claims to be.

        Returns:
            dict: Same structure as identify_user(). Additionally:
                  {"match": False, "reason": "User not enrolled"}
                  if the claimed_user_id has no stored embedding.
        """
        stored_emb = self.db_manager.get_embedding(claimed_user_id)
        if stored_emb is None:
            return {"match": False, "reason": "User not enrolled"}

        live_emb = self.generate_embedding(face_image)
        if live_emb is None:
            return {"match": False, "reason": "Embedding failed"}

        if stored_emb.shape != live_emb.shape:
            print(
                f"[FaceRecognizer] verify_user: dimension mismatch for "
                f"user {claimed_user_id} — stored {stored_emb.shape}, live {live_emb.shape}"
            )
            return {"match": False, "reason": "Embedding dimension mismatch"}

        score = cosine_similarity(live_emb, stored_emb)

        if is_match(score, SIMILARITY_THRESHOLD):
            return {
                "match": True,
                "user_id": claimed_user_id,
                "similarity": float(score),
                "confidence_pct": round(score * 100, 1),
            }

        return {
            "match": False,
            "similarity": float(score),
            "reason": "No match found",
        }

    def compare_embeddings(self, emb1: np.ndarray, emb2: np.ndarray) -> float:
        """
        Thin wrapper around cosine_similarity for use by callers who
        already hold two embedding arrays and want a direct comparison.

        Args:
            emb1 (np.ndarray): L2-normalized float32 embedding.
            emb2 (np.ndarray): L2-normalized float32 embedding, same shape.

        Returns:
            float: Cosine similarity in [0.0, 1.0].
        """
        return cosine_similarity(emb1, emb2)

    def get_enrollment_status(self, user_id: str) -> dict:
        """
        Check whether a user has a stored embedding in the database.

        Args:
            user_id (str): User identifier to check.

        Returns:
            dict: {"enrolled": True,  "user_id": user_id}
                  {"enrolled": False, "user_id": user_id}
        """
        emb = self.db_manager.get_embedding(user_id)
        return {"enrolled": emb is not None, "user_id": user_id}
