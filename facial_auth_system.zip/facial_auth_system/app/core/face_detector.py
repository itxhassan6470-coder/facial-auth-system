"""
app/core/face_detector.py

Module 2: Face Detection
-------------------------
Pure vision utility for detecting a face in a single video frame,
extracting a normalized face crop, and returning dlib's 68-point
facial landmarks. Has ZERO database dependencies and ZERO knowledge
of liveness detection, embeddings, or UI — those belong to later
modules.

====================================================================
DLIB MODEL FILE — MANUAL SETUP INSTRUCTIONS
====================================================================
This module requires dlib's pretrained 68-point facial landmark
predictor. It is NOT bundled with dlib and must be downloaded
separately (one time only):

  1. Download URL:
       http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2

  2. Extract the .dat file from the .bz2 archive. On Linux/macOS:
       bzip2 -d shape_predictor_68_face_landmarks.dat.bz2
     On Windows, use 7-zip (or any tool that supports .bz2) to
     extract it, or simply run download_models.py (see below),
     which does this automatically using Python's built-in bz2
     module.

  3. Place the resulting .dat file at:
       models/shape_predictor_68_face_landmarks.dat

  4. The models/ folder lives at the project root, i.e. as a
     sibling of app/, config.py, and requirements.txt.

For convenience, a helper script `download_models.py` is provided
at the project root which automates steps 1-3: it downloads the
.bz2 file, shows download progress, extracts it, and saves it to
the correct location. Run it once with:

    python download_models.py
====================================================================
"""

import os
import cv2
import dlib
import numpy as np

from config import (
    SHAPE_PREDICTOR_PATH,
    FACE_IMAGE_SIZE,
    FACE_PADDING,
    MIN_FACE_QUALITY,
    MIN_FACE_CONFIDENCE,
)


class FaceDetector:
    """
    Detects faces in a single frame using dlib's HOG-based frontal
    face detector, and extracts 68-point facial landmarks using
    dlib's pretrained shape predictor.

    This class is stateless with respect to video capture: it never
    opens a webcam itself. Callers are responsible for supplying
    frames (e.g. read from cv2.VideoCapture) to detect_face().
    """

    def __init__(self):
        """
        Loads dlib's HOG-based frontal face detector and the 68-point
        shape predictor model.

        Raises:
            FileNotFoundError: If the shape predictor .dat file is
                not found at SHAPE_PREDICTOR_PATH. The error message
                includes download instructions.
        """
        if not os.path.exists(SHAPE_PREDICTOR_PATH):
            raise FileNotFoundError(
                "\n\nMissing dlib shape predictor model file.\n"
                f"Expected to find it at: {SHAPE_PREDICTOR_PATH}\n\n"
                "To fix this:\n"
                "  1. Download from:\n"
                "     http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2\n"
                "  2. Extract the .dat file from the .bz2 archive\n"
                "     (e.g. `bzip2 -d shape_predictor_68_face_landmarks.dat.bz2`,\n"
                "     or use 7-zip on Windows)\n"
                "  3. Place the .dat file at:\n"
                f"     {SHAPE_PREDICTOR_PATH}\n\n"
                "Or simply run the helper script from the project root:\n"
                "     python download_models.py\n"
            )

        # HOG-based detector: fast, CPU-only, no GPU required.
        # (Intentionally NOT using dlib's CNN face detector.)
        self.detector = dlib.get_frontal_face_detector()
        self.predictor = dlib.shape_predictor(str(SHAPE_PREDICTOR_PATH))

        print("Face detector initialized successfully")

    def detect_face(self, frame):
     
        if frame is None or not isinstance(frame, np.ndarray) or frame.size == 0:
            return None

        frame_h, frame_w = frame.shape[:2]

        # dlib expects RGB, OpenCV gives BGR.
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Run detection on grayscale (standard for dlib HOG detector).
        detections = self.detector(gray_frame, 1)

        if len(detections) == 0:
            return None

        # Pick the largest face by bounding box area.
        largest = max(detections, key=lambda rect: rect.width() * rect.height())

        # Landmarks are computed on the RGB frame at full resolution,
        # using the original (unpadded) dlib rectangle.
        landmarks = self.predictor(rgb_frame, largest)

        x = largest.left()
        y = largest.top()
        w = largest.width()
        h = largest.height()

        # Clip the raw bbox to frame bounds before computing confidence.
        x_clip = max(0, x)
        y_clip = max(0, y)
        w_clip = min(x + w, frame_w) - x_clip
        h_clip = min(y + h, frame_h) - y_clip
        w_clip = max(w_clip, 0)
        h_clip = max(h_clip, 0)

        frame_area = float(frame_w * frame_h)
        bbox_area = float(w_clip * h_clip)
        confidence = (bbox_area / frame_area) if frame_area > 0 else 0.0

        # Crop with padding, clamped to frame bounds.
        x1 = max(0, x - FACE_PADDING)
        y1 = max(0, y - FACE_PADDING)
        x2 = min(frame_w, x + w + FACE_PADDING)
        y2 = min(frame_h, y + h + FACE_PADDING)

        face_crop = rgb_frame[y1:y2, x1:x2]

        if face_crop.size == 0:
            # Degenerate crop (shouldn't normally happen) — treat as no detection.
            return None

        face_image = cv2.resize(
            face_crop, (FACE_IMAGE_SIZE, FACE_IMAGE_SIZE), interpolation=cv2.INTER_AREA
        )

        if confidence < MIN_FACE_CONFIDENCE:
            confidence = 0.0

        return {
            "bbox": (int(x), int(y), int(w), int(h)),
            "landmarks": landmarks,
            "face_image": face_image,
            "confidence": float(confidence),
            "frame_shape": (int(frame_h), int(frame_w)),
        }

    def get_landmark_points(self, landmarks):
        """
        Convert a dlib full_object_detection shape into a plain list
        of (x, y) tuples. Useful for downstream modules (e.g. blink
        detection in Module 4) that don't want to depend on dlib types.

        Args:
            landmarks (dlib.full_object_detection): Shape object
                returned in detect_face()'s "landmarks" key.

        Returns:
            list[tuple[int, int]]: 68 (x, y) points, in dlib's
            canonical landmark order.
        """
        return [(landmarks.part(i).x, landmarks.part(i).y) for i in range(68)]

    def get_eye_landmarks(self, landmarks):
        """
        Extract just the eye landmark points, split into left/right.

        Note on indices (per the project spec, required as-is for
        Module 4 blink detection): "left_eye" uses dlib points 42-47
        and "right_eye" uses dlib points 36-41.

        Args:
            landmarks (dlib.full_object_detection): Shape object
                returned in detect_face()'s "landmarks" key.

        Returns:
            dict: {
                "left_eye":  [(x, y), ...],  # 6 points, dlib indices 42-47
                "right_eye": [(x, y), ...]   # 6 points, dlib indices 36-41
            }
        """
        left_eye = [(landmarks.part(i).x, landmarks.part(i).y) for i in range(42, 48)]
        right_eye = [(landmarks.part(i).x, landmarks.part(i).y) for i in range(36, 42)]
        return {"left_eye": left_eye, "right_eye": right_eye}

    def draw_detection(self, frame, detection_result):
        """
        Draw a green bounding box, blue landmark dots, and a label
        onto a copy of the frame.

        Args:
            frame (np.ndarray): Original BGR frame.
            detection_result (dict | None): Output of detect_face().

        Returns:
            np.ndarray: Annotated BGR frame (new array; original is
            not modified). If detection_result is None, returns an
            unmodified copy of frame.
        """
        annotated = frame.copy()

        if detection_result is None:
            return annotated

        x, y, w, h = detection_result["bbox"]
        landmarks = detection_result["landmarks"]

        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)

        for i in range(68):
            px, py = landmarks.part(i).x, landmarks.part(i).y
            cv2.circle(annotated, (px, py), 2, (255, 0, 0), -1)

        label_y = max(0, y - 10)
        cv2.putText(
            annotated,
            "Face Detected",
            (x, label_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )

        return annotated

    def is_face_centered(self, detection_result, tolerance=0.25):
        """
        Check whether the detected face's center lies within the
        middle region of the frame.

        Args:
            detection_result (dict | None): Output of detect_face().
            tolerance (float): Half-width (as a fraction of frame
                dimension) of the "centered" zone, applied symmetrically
                around the frame center. E.g. tolerance=0.25 means the
                face center must fall within the middle 50% of the
                frame on both the x and y axes.

        Returns:
            bool: True if centered, False otherwise (including when
            detection_result is None).
        """
        if detection_result is None:
            return False

        x, y, w, h = detection_result["bbox"]
        frame_h, frame_w = detection_result["frame_shape"]

        face_center_x = x + w / 2.0
        face_center_y = y + h / 2.0

        frame_center_x = frame_w / 2.0
        frame_center_y = frame_h / 2.0

        x_bound = frame_w * tolerance
        y_bound = frame_h * tolerance

        within_x = abs(face_center_x - frame_center_x) <= x_bound
        within_y = abs(face_center_y - frame_center_y) <= y_bound

        return bool(within_x and within_y)

    def get_face_quality_score(self, face_image):
        """
        Estimate image sharpness/quality using the variance of the
        Laplacian. Blurry images have low variance; sharp images have
        high variance.

        Args:
            face_image (np.ndarray): RGB (or grayscale) face crop,
                typically the "face_image" from detect_face().

        Returns:
            float: Normalized quality score in [0.0, 1.0], computed
            as min(laplacian_variance / 500.0, 1.0).
        """
        if face_image is None or not isinstance(face_image, np.ndarray) or face_image.size == 0:
            return 0.0

        if face_image.ndim == 3:
            gray = cv2.cvtColor(face_image, cv2.COLOR_RGB2GRAY)
        else:
            gray = face_image

        variance = cv2.Laplacian(gray, cv2.CV_64F).var()
        score = min(variance / 500.0, 1.0)

        return float(score)
