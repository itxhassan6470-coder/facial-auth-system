"""
run.py

Entry point for the FaceAuth Flask web application.

Run with:
    python run.py

The app starts at: http://localhost:5000
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.web.extensions import create_app

if __name__ == "__main__":
    app = create_app()
    print("\n[FaceAuth] Starting server at http://localhost:5000\n")
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False,   # set True during development to see tracebacks
        threaded=True, # required -- ML inference + Flask requests run concurrently
    )
