"""
config.py

App-wide constants and configuration values for the Facial Biometric
Authentication System. This file centralizes all paths and tunable
parameters used across modules.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# Core paths
# ---------------------------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "facial_auth.db"
MODELS_DIR = BASE_DIR / "models"
LOGS_DIR = BASE_DIR / "logs"

# Ensure required directories exist
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Face recognition settings (stubs for later modules)
# ---------------------------------------------------------------------------
EMBEDDING_DIM = 128
SIMILARITY_THRESHOLD = 0.65  # Tune later in Module 3

# ---------------------------------------------------------------------------
# Liveness settings (stubs for later modules)
# ---------------------------------------------------------------------------
BLINK_EAR_THRESHOLD = 0.25
BLINK_CONSEC_FRAMES = 2
EASYSHIELD_MODEL_PATH = MODELS_DIR / "best.pt"
EASYSHIELD_CONF_THRESHOLD = 0.5  # Tune in Module 4
REQUIRE_BLINK = True
LIVENESS_CHECK_FRAMES = 30

# ---------------------------------------------------------------------------
# App settings
# ---------------------------------------------------------------------------
ENROLLMENT_SAMPLES = 10  # Number of face captures per user
ADMIN_ROLE = "admin"
USER_ROLE = "user"
# === MODULE 2 ADDITIONS ===
SHAPE_PREDICTOR_PATH = MODELS_DIR / "shape_predictor_68_face_landmarks.dat"
FACE_IMAGE_SIZE = 160
FACE_PADDING = 20
MIN_FACE_QUALITY = 0.15
MIN_FACE_CONFIDENCE = 0.01

# ---------------------------------------------------------------------------
# Module 3: Face recognition model settings
# ---------------------------------------------------------------------------
FACE_MODEL_NAME        = "Facenet"
MIN_ENROLLMENT_SAMPLES = 5          # Minimum valid embeddings to accept enrollment
# ---------------------------------------------------------------------------
# Module 4: Liveness detection settings
# ---------------------------------------------------------------------------
BLINK_EAR_THRESHOLD       = 0.25
BLINK_CONSEC_FRAMES       = 2
LEFT_EYE_INDICES          = [42, 43, 44, 45, 46, 47]
RIGHT_EYE_INDICES         = [36, 37, 38, 39, 40, 41]
EASYSHIELD_MODEL_PATH     = MODELS_DIR / "best.pt"
EASYSHIELD_CONF_THRESHOLD = 0.5
REQUIRE_BLINK             = True
LIVENESS_CHECK_FRAMES     = 15